# Getting Sieve onto other people's machines

Native packages, three of them: **AUR** for Arch and Omarchy, **`.deb`** for
Debian and Ubuntu, **`.rpm`** for Fedora. No Flatpak.

Written after checking the target rather than assuming it.

## Why native, and what it costs

The machine this is built on says most of it:

```
flatpak      — not installed, no remotes configured
yay          /usr/bin/yay          pacman   /usr/bin/pacman
gtk4         4.22.4                libadwaita  1.9.3
sqlite       3.53.4                openssl     3.6.3
tor          0.4.9.11 in extra
```

Omarchy is Arch and ships an AUR helper with **no Flatpak at all**. Shipping
only a Flatpak would ask every user here to install Flatpak, add Flathub,
restart their session and download a few hundred megabytes of GNOME runtime —
in order to run a native GTK4 application on a machine that already has GTK4
4.22 and libadwaita 1.9.

Three things native packaging wins outright:

- **Nothing to install first.** One command, using the GTK the machine
  already has.
- **Hardware wallets actually work.** USB HID in a sandbox needs
  `--device=all`, the escape hatch that hands the app every device on the
  machine — and it *still* needs udev rules the sandbox cannot install. A
  native package installs those rules itself. `hardware::udev_hint()` already
  promises this: *"the packaged build of Sieve will ship them."*
- **No bundled Tor anywhere.** `tor::daemon::find` looks on `PATH` as well as
  beside the executable, and `tor` is a package on all three families. The
  Expert Bundle machinery existed for the sandbox and now has no user.

And three things it costs, which are real:

- **A build matrix.** One artefact per distribution family and per release,
  built against that release's glibc and GTK. Flatpak's whole pitch is
  building once.
- **A version floor with no way around it.** `gnome_46` means **libadwaita
  1.5 or newer**. Anything older cannot run this binary, and a Flatpak would
  have carried its own libadwaita for exactly those machines. Ubuntu 22.04
  and Debian 12 are out; there is no fix short of lowering the baseline, and
  `CLAUDE.md` records why it is where it is.
- **No sandbox.** Sieve reads and writes its own data directory and talks to
  the network, and that is now bounded by the user account rather than by a
  manifest.

That is a fair trade for a wallet whose users are the sort of people who
already have `yay`. It is worth writing down that it *is* a trade.

## What three packages cover, and what they miss

| Family | Reaches |
|---|---|
| AUR | Arch, Omarchy, Manjaro, EndeavourOS, CachyOS, Garuda |
| `.deb` | Debian, Ubuntu, Mint, Pop!_OS, elementary, Zorin, KDE neon, Raspberry Pi OS |
| `.rpm` | Fedora, RHEL, Alma, Rocky, Nobara |

That is most of what people actually run. What it misses, in the order it is
likely to matter:

- **Immutable distributions** — Silverblue, Kinoite, Bazzite, SteamOS. Flatpak
  is the native idiom there and layering an `.rpm` with `rpm-ostree` works but
  is discouraged. This is the real cost of not shipping a Flatpak, and it is
  the one that would bring the decision back if people ask.
- **openSUSE**, which is RPM with different package names, so a Fedora `.rpm`
  may not resolve. A second spec rather than a new format; cheap when someone
  wants it.
- **NixOS**, which needs a derivation of its own and whose users usually write
  one.
- **Ubuntu 22.04 and Debian 12**, excluded by the libadwaita floor in any
  format. Only a Flatpak carrying its own libadwaita, or lowering the
  baseline, would reach them.
- **Gentoo, Alpine, Void** and the rest, who build from source — which works
  anywhere the libraries are new enough, and is what those users expect.

## The version floor, which decides the matrix

Sieve needs **libadwaita ≥ 1.5** (GNOME 46) and **GTK ≥ 4.14**. Every target
below is a claim to be checked by building in a container of that release,
not from memory:

| Target | Expected to clear the floor |
|---|---|
| Arch, Omarchy | yes, rolling |
| Fedora 40+ | yes |
| Ubuntu 24.04 LTS, 24.10+ | yes |
| Debian 13 (trixie) | yes |
| Ubuntu 22.04 LTS, Debian 12 | **no** — libadwaita too old |

The build itself must happen *on* the oldest target of each family, in a
container, because a binary linked against newer glibc will not run on older.

## Channel one — AUR

`yay -S sieve`.

```bash
pkgname=sieve
pkgdesc="A privacy-focused Bitcoin wallet"
arch=('x86_64')
license=('MIT' 'Apache-2.0')
depends=('gtk4' 'libadwaita' 'sqlite' 'openssl')
makedepends=('cargo' 'git')
optdepends=('tor: route every connection through Tor')

build()   { cargo build --release --frozen }
check()   { cargo test --frozen }
package() {
  install -Dm755 target/release/sieve "$pkgdir/usr/bin/sieve"
  install -Dm644 data/com.galaxoidlabs.Sieve.desktop \
    "$pkgdir/usr/share/applications/com.galaxoidlabs.Sieve.desktop"
  install -Dm644 data/icons/hicolor/scalable/apps/bitcoin-logo.svg \
    "$pkgdir/usr/share/icons/hicolor/scalable/apps/com.galaxoidlabs.Sieve.svg"
  install -Dm644 packaging/udev/51-sieve-hardware.rules \
    "$pkgdir/usr/lib/udev/rules.d/51-sieve-hardware.rules"
}
```

Three variants, in the order they are worth making: **`sieve`** from a tagged
release tarball, **`sieve-git`** from `master` for early testers, and
**`sieve-bin`** last — a prebuilt binary is a trust decision, so it waits for
signed tags and checksums.

**The icon must be installed by hand.** It is compiled into the binary as a
gresource for the app's own use, which does nothing for the desktop's icon
theme: the `.desktop` file says `Icon=com.galaxoidlabs.Sieve`, and that name
has to exist in hicolor on disk. Cargo installs no data files.

## Being found on Omarchy

Installing and being discovered are different problems, and Omarchy has four
surfaces for the second. They are a ladder: each rung needs the one below it,
and only the first is self-serve.

Read off the machine rather than guessed — the catalogue is
`/usr/share/omarchy/default/omarchy/omarchy-menu.jsonc`, the repo is
configured in `/etc/pacman.conf`.

### 1. The AUR, which needs nobody's permission

Publishing `sieve` makes it findable immediately:

```
yay -Ss bitcoin wallet
```

Omarchy's own menu has a generic **Install → AUR** entry
(`omarchy-pkg-aur-install`) that drops into an AUR search, so this rung alone
means somebody looking for a Bitcoin wallet on Omarchy can find one. Search
matches on `pkgdesc`, so it is worth writing for a person rather than for a
manifest.

### 2. The Omarchy menu, which is the real path

`Super+Alt+Space` → **Install** → a category. The catalogue is curated JSONC
and an entry is one line:

```jsonc
"install.ai.lm-studio": {"icon":"","label":"LM Studio",
  "when":"! omarchy-pkg-present lmstudio-bin",
  "action":"omarchy-install-app 'LM Studio' lmstudio-bin"}
```

Sieve's would be the same shape, guarded by `! omarchy-pkg-present sieve` so
it disappears once installed. Getting there is a **pull request to Omarchy**,
which is a human decision and wants a package that already exists and works.

The categories today are `ai`, `browser`, `development`, `editor`, `gaming`,
`service`, `style`, `terminal`, `tui`, `webapp`, `windows`. There is no
finance category, so the PR either proposes one or argues for a home in an
existing one — and being the reason a category exists is a harder sell than
being the third entry in one.

### 3. The `[omarchy]` binary repository

```
[omarchy]
Server = https://pkgs.omarchy.org/stable/$arch
```

Already configured on every Omarchy machine. A package there installs as fast
as any system package with no AUR build, and it is where most menu entries
point. Also a curation decision, and the top rung rather than the first.

### 4. The launcher, after installation

`data/com.galaxoidlabs.Sieve.desktop` already carries
`Categories=GNOME;GTK;Office;Finance;` and `Keywords=Bitcoin;Wallet;Privacy;`,
so Sieve answers a launcher search for "bitcoin" or "wallet" — **provided the
package installs the desktop entry and the icon under the name the entry
asks for**. That is the gap noted above, and it is what makes this rung work
at all.

### The order

Publish to the AUR → install it on Omarchy from the AUR and confirm the menu,
launcher and udev rules all behave → open a pull request adding one line to
the menu → and if it earns a place, the binary repository follows.

## Channels two and three — `.deb` and `.rpm`

Both generated from `Cargo.toml` metadata rather than hand-written packaging
trees:

- **`cargo-deb`** — `[package.metadata.deb]` for depends, the desktop entry,
  the icon and the udev rules.
- **`cargo-generate-rpm`** — `[package.metadata.generate-rpm]`, same list.

Runtime dependencies by family:

| | Debian / Ubuntu | Fedora |
|---|---|---|
| GTK | `libgtk-4-1` | `gtk4` |
| Adwaita | `libadwaita-1-0` | `libadwaita` |
| SQLite | `libsqlite3-0` | `sqlite-libs` |
| TLS | `libssl3` | `openssl-libs` |
| Tor | `Suggests: tor` | `Recommends: tor` |

Built in containers — `debian:trixie`, `ubuntu:24.04`, `fedora:41` — from a
release tag, in CI, so the artefacts are reproducible by someone else and not
by this laptop.

## Releases, by CI rather than by hand

Three artefacts built on three distributions, checksummed, signed and
published every time — that is exactly the work a person does badly and a
machine does the same way twice. There is no remote yet, so this is the shape
to build when there is one.

**One trigger: pushing a tag.** `v0.2.0` and nothing else. No release from a
branch, no manual dispatch that quietly builds something other than what the
tag says.

```
.github/workflows/release.yml

  check     tag matches the version in Cargo.toml, or stop
            cargo fmt --check · cargo clippy -D warnings · cargo test

  arch      container: archlinux:base-devel
            makepkg --syncdeps, then install the result and run `sieve --version`

  deb       container: debian:trixie      → cargo-deb
            container: ubuntu:24.04       → cargo-deb
            install into a clean container of the same image, and run it

  rpm       container: fedora:41          → cargo-generate-rpm
            install into a clean container, and run it

  publish   SHA256SUMS over every artefact, signed
            GitHub Release with the notes from the tag
            push the PKGBUILD to the AUR over SSH
```

Five things worth getting right, each of which is a way this goes wrong
quietly:

- **The version guard comes first.** A tag that disagrees with `Cargo.toml`
  produces packages whose filename lies about their contents. Cheapest
  possible check, first job, everything else depends on it.
- **Build in a container of the *oldest* target of each family.** glibc is
  forwards compatible and not backwards: a binary linked on Ubuntu 24.10 will
  not run on 24.04. Pin the images by digest so a base image moving does not
  silently change what shipped.
- **Install what was built, in a clean container, and run it.** Not `--help`
  in the build container that already has every dev library — a fresh
  container with only the declared dependencies, which is the only way the
  dependency list is ever actually tested. It needs a headless display to get
  past GTK initialisation; `xvfb-run` or `WAYLAND_DISPLAY=` with a nested
  compositor, whichever proves less trouble.
- **`--locked` everywhere**, and commit `Cargo.lock`. A release that resolves
  its own dependencies is a release nobody can reproduce.
- **Sign the checksums, not the files.** One signature over `SHA256SUMS` is
  what `sieve-bin`'s PKGBUILD verifies and what a person can check by hand.
  The key lives in repository secrets and nowhere else; rotating it is a
  release note, not a silent event.

**The AUR step is different from the others** and worth separating. CI does
not build the AUR package — the AUR builds it, on the user's machine, from
source. What CI pushes is the `PKGBUILD` and `.SRCINFO` for the new version,
over SSH with a deploy key. So the Arch job's purpose is not to produce an
artefact but to **prove the PKGBUILD still works** before that push: build it,
install it, run it. A broken PKGBUILD in the AUR is broken for everybody who
tries to install until somebody notices.

`sieve-bin` is the exception — it points at the release tarball and its
checksum, both of which the publish job has just produced, so its PKGBUILD is
generated rather than maintained.

## Hosting

**GitHub Releases first**: three files and a `SHA256SUMS`, signed. Enough for
`sieve-bin`, enough for anyone who wants to install by hand, and it costs
nothing to maintain.

**A real repository later**, if there is demand. apt and dnf repositories
mean signing keys, key rotation and hosting; the openSUSE Build Service will
build and host both for free from one spec, which is the least-effort route
if it comes to that. Not before there are users asking.

## The udev rules, which are new work

Hardware wallets are invisible to a non-root process until udev says
otherwise, and this is the thing a Flatpak cannot fix and a native package
can. `packaging/udev/51-sieve-hardware.rules` needs writing, taking the
vendor and product ids the vendors publish for Ledger, Coldcard, Trezor,
BitBox and Jade, and tagging them `uaccess` so the logged-in user can open
them.

Then `hardware::udev_hint()` can stop promising and start pointing: the rules
are installed, so if a device is still invisible the answer is to replug it
or check the device is unlocked.

## Order of work

1. **Write the udev rules**, and confirm a Ledger appears without root once
   they are installed.
2. **Write the PKGBUILD and `makepkg -si` it here.** Prove the binary, the
   desktop entry, the icon and the rules all land where they should.
3. **Tag a release**, signed, so there is something for a package to point at.
4. **Add `cargo-deb` and `cargo-generate-rpm` metadata**, and build both in
   containers.
5. **Verify the floor claims** by installing the artefacts in
   `ubuntu:24.04`, `debian:trixie` and `fedora:41` containers and running the
   binary under a nested Wayland session.
6. **Publish to GitHub Releases, then submit to AUR.**

## What is now dead

`packaging/com.galaxoidlabs.Sieve.yml` and `scripts/fetch-tor.sh` exist to
build Tor into a Flatpak. With no Flatpak, nothing uses them. Keep them until
the AUR package is proven — they are the only record of how to bundle Tor —
then delete them and say so in `ROADMAP.md`, because a manifest nobody builds
is a manifest that rots.
